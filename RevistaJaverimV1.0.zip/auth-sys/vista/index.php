<?php include 'partials/head.php';?>
<?php include 'partials/menu.php';?>

<div class="container">

	<div class="starter-template">
		<br>
		<br>
		<br>
		<div class="jumbotron">
			<div class="container">
				<h1>Biblioteca Javerim Aprendices</h1>
				<p>Seccion inicio</p>
				<p>
					<a href="login.php" class="btn btn-primary btn-lg">Ingreso</a>
				</p>
			</div>
		</div>
	</div>

</div><!-- /.container -->

<?php include 'partials/footer.php';?>