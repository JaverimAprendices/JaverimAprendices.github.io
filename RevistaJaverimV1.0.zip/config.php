<?php
    //Host
    $host = "localhost";
    //dbname
    $dbname = "c19283_authsys";
    //user
    $user = "Javerim";  
    //pass
    $pass = "4qD0Q1nOqsXN";

    $conn = new PDO("mysql:host=$host;dbname=$dbname",$user,$pass);

     if($conn == true) {
        echo "It´s Working Fine";
     }else{
        echo "Connection is wrong: err";

     }




?>